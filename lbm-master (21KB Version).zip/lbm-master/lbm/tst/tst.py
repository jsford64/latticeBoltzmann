# Generic imports
import warnings

# Filter warning messages
warnings.filterwarnings('ignore',category=DeprecationWarning)
